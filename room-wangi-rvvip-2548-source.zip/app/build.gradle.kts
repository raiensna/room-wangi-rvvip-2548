plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.roomwangi.rvvip2548"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.roomwangi.rvvip2548"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
