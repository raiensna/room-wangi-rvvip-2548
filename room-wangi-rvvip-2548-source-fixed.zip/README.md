# ROOM WANGI R.VVIP 2548

Starter Android project and GitHub Actions workflow.

## Build APK from GitHub on Android phone
1. Upload the contents of this ZIP into the root of your private repository.
2. Open the repository on GitHub in Chrome.
3. Open the **Actions** tab and enable workflows if GitHub asks.
4. Select **Build Android APK** and press **Run workflow**.
5. Wait for the run to finish, open it, and download the artifact `room-wangi-rvvip-2548-debug`.
6. Extract the ZIP artifact to get `app-debug.apk`.

## Important limitation
This is an initial UI/import prototype. It can select an `.ovpn` file, but it does **not** establish a VPN connection yet. A supported OpenVPN engine integration, VPN permission flow, profile parsing, and connection lifecycle still need to be implemented and tested. Do not include private keys, passwords, or `.ovpn` files in this repository.


## Perbaikan build
Konfigurasi Java dan Kotlin disamakan ke JVM 17 untuk mengatasi error
`Inconsistent JVM-target compatibility` pada GitHub Actions.

## Catatan penting
Proyek ini masih berupa prototipe tampilan dan impor berkas `.ovpn`.
Ini **belum** menyertakan mesin OpenVPN, sehingga belum dapat membuat
koneksi VPN sungguhan.
