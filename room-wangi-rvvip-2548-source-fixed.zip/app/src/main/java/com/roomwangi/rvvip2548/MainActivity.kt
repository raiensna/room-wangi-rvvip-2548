package com.roomwangi.rvvip2548

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val pickFile = 41
    private lateinit var status: TextView
    private lateinit var selected: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(22, 22, 24)
        window.navigationBarColor = Color.rgb(22, 22, 24)
        showSplash()
    }

    private fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(20, 20, 22))
        }
    }

    private fun showSplash() {
        val box = base().apply { gravity = Gravity.CENTER }
        val mark = TextView(this).apply {
            text = "◉"
            textSize = 92f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(239, 112, 25))
        }
        val name = TextView(this).apply {
            text = "ROOM WANGI\nR.VVIP 2548"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        box.addView(mark)
        box.addView(name)
        setContentView(box)
        box.postDelayed({ showHome() }, 1200)
    }

    private fun showHome() {
        val box = base()
        val header = TextView(this).apply {
            text = "☰    ROOM WANGI R.VVIP 2548"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 30)
        }
        status = TextView(this).apply {
            text = "DISCONNECTED"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 24)
        }
        val title = TextView(this).apply {
            text = "SERVER ROOM WANGI"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(0, 10, 0, 12)
        }
        selected = TextView(this).apply {
            text = "Belum ada konfigurasi server"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 24)
        }
        val import = Button(this).apply {
            text = "IMPORT SERVER (.OVPN)"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(i, pickFile)
            }
        }
        val connect = Button(this).apply {
            text = "CONNECT"
            setOnClickListener {
                Toast.makeText(this@MainActivity,
                    "Mesin OpenVPN belum diintegrasikan. Ini hanya build awal UI/import.",
                    Toast.LENGTH_LONG).show()
            }
        }
        val note = TextView(this).apply {
            text = "Build awal: pemilihan file .ovpn tersedia. Koneksi VPN belum aktif sampai mesin OpenVPN resmi diintegrasikan."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 24, 0, 0)
        }
        box.addView(header)
        box.addView(status)
        box.addView(title)
        box.addView(selected)
        box.addView(import)
        box.addView(connect)
        box.addView(note)
        setContentView(box)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFile && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            selected.text = "Konfigurasi dipilih:\n${uri.lastPathSegment ?: "file .ovpn"}"
            Toast.makeText(this, "File dipilih. Koneksi belum aktif.", Toast.LENGTH_SHORT).show()
        }
    }
}
