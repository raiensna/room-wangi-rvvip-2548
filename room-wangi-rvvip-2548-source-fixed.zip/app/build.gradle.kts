plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.roomwangi.rvvip2548"
    compileSdk = 35

    // Keep Java and Kotlin bytecode targets aligned for GitHub Actions.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    defaultConfig {
        applicationId = "com.roomwangi.rvvip2548"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
